# CLAUDE.md — Tesis de Magíster 2027 (Felipe Gajardo Ávalos, USACH)

Este archivo es el punto de entrada para Claude Code. Léelo completo antes de trabajar en esta carpeta.

## 1. Quién y qué
- **Estudiante:** Felipe Salvador Gajardo Ávalos. Ingeniero Civil Eléctrico (PUCV). Magíster en Ciencias de la Ingeniería, mención Eléctrica, USACH (ingresó en 1-2026). Docente de Circuitos Eléctricos I en USACH.
- **Profesor guía:** Dr. Enrique Espina González (USACH). Su tesis doctoral (U. Chile / U. Waterloo, 2021, control secundario distribuido por consenso en Micro-redes híbridas AC/DC) y su tesis de magíster (U. Chile, 2017, droop por fase en Micro-redes de 4 hilos, PLECS) son la base metodológica.
- **Reunión semanal:** lunes 17:00, Laboratorio E2Tech, con Espina, Bernhardt Gotschlich e Ignacio Staforelli (hasta el 21-dic-2026).
- **Próxima reunión:** lunes **16-nov-2026**. Llevar las láminas de `documentos/presentaciones/laminas_reunion_16nov.tex` y la simulación PLECS de una Micro-red DC.

## 2. El tema hoy (al 12-nov-2026)
**Gestión jerárquica de un alimentador BT trifásico de 4 hilos con Micro-redes DC por fase.**

El alimentador ya está desbalanceado por clientes monofásicos sin gestión. En cada fase φ ∈ {a, b, c} hay N_φ Micro-redes DC residenciales (FV, BESS, EV, cargas), cada una conectada a su fase por un IC monofásico. No hay barra DC común: las Micro-redes solo intercambian energía a través del alimentador. Los IC se usan como actuadores para gestionar, desde la cabecera, la compra de energía y el balance entre fases.

Arquitectura vigente (detalle en `CRONOLOGIA.md` → "Decisiones vigentes"):

| Nivel | Cuántos / cada cuánto | Mide o recibe | Decide | Envía a |
|---|---|---|---|---|
| Terciario | 1 central, 15 min, H = 12 h | envolvente 𝓔_k y energía E_k de cada MR, tarifa, demanda no gestionada | **solo energía** (mín. compra, LP): plan P*_k y reserva r↑_k, r↓_k | IC_k; R_φ = Σr_k al lazo rápido |
| Lazo rápido | 1 por fase, ~1 s | P_h,φ en cabecera; reserva de la fase | **solo balance**: e_φ = P_h,φ − P̄_h, PI saturado → ΔP_φ; u_φ = ΔP_φ/R_φ | IC de la fase (ΔP_k = u_φ r_k) |
| Secundario | 1 por MR, s | V_dc,k, SoC de BESS/EV, FV disponible | restaura V_dc, reparte entre sus DER, cuida límites, calcula su envolvente | primario de cada DER; envolvente al terciario (vía IC) |
| Primario | 1 por convertidor, ms | locales | DER: droop V_dc–P · IC: grid-following, P_ref = P*_k + u_φ r_k, Q_ref = 0 | — |

**Resultados analíticos propios** (se usan para defender decisiones):
- **R1:** con tensión de cabecera balanceada, I₀ = I₂ = 0 ⇔ S_h,a = S_h,b = S_h,c. Por eso "igualar las potencias por fase" equivale a anular las secuencias.
- **R2 (paralelogramo):** |I₀|² + |I₂|² = 2|B|² + 2|C|², con B el desbalance de P y C el de Q. Q no puede reducir el desbalance activo.
- **Piso energético:** con ΔSOC = 0 en el día, la media diaria del desbalance activo no la corrige ningún control. Es un tema de diseño, no de control.
- **Caso simple:** la energía disponible fija cuánto se corrige; la forma de gastarla fija el pico. Repartir parejo es óptimo (por convexidad), y por eso H ≥ duración del evento.

## 3. Mapa de la carpeta
```
CLAUDE.md                 ← este archivo
README.md                 ← índice completo, qué se incluyó y qué no
CRONOLOGIA.md             ← evolución del tema, decisiones vigentes y obsoletas
ENLACES.md                ← chats de claude.ai + toda la bibliografía con enlace
memoria/                  ← memoria de Claude sobre la tesis (thesis-overview.md = estado más completo) y perfil
conversaciones/           ← resumen de cada chat del Proyecto (pedidos, resultados, correos del profesor)
documentos/presentaciones ← Beamer (XeLaTeX); laminas_reunion_16nov.tex es la vigente
documentos/pautas         ← guiones de reunión, matemática y bibliografía comentada
documentos/correos        ← respuesta al correo del 2-nov
documentos/simulacion     ← PLECS + referencia Python + prototipos cvxpy; historico_ley_soc/ = etapa descartada
referencias/              ← documento de orientación de julio 2026 (PDF + texto extraído)
```

## 4. Cómo trabajar con Felipe
- **Idioma:** español de Chile, registro técnico. Escribir "Micro-red" con guion.
- **Estilo:** directo, con datos, sin suavizar ("verdad cruda"). Todo detallado y documentado. Explicaciones paso a paso, con rigor matemático y claridad física. Distinguir lo comprobado de lo supuesto o inferido, y no omitir supuestos.
- **Antes de cada reunión:** preparar un banco de preguntas y contraargumentos. Felipe tiene que poder defender cada ecuación ante el profesor.
- **Láminas:** livianas en texto y basadas en diagramas. El material de respaldo va aparte. Presentar el tema como propuesta, no como "corrección". No incluir prototipos ni validación si no se piden.
- **LaTeX:**
  - Plantilla de clases USACH: `beamer`, `aspectratio=169`, XeLaTeX con `fontspec` + `polyglossia` (español).
  - Colores: teal `#009688`, naranjo `#E77500`; código de colores por nivel: terciario naranjo, lazo rápido verde `#2E8B57`, secundario teal, primario azul `#1F5FAF`.
  - Fondos `fig/fondo_usach_portada.png` y `fig/fondo_usach_contenido.png`. **No están en esta carpeta**; pedírselos a Felipe para compilar.
  - Referencias en formato IEEE.
- **Convenciones de signo:** P_IC > 0 = DC→AC (inyecta a la red); P_B > 0 = la batería descarga; P_h > 0 = el alimentador importa desde la S/E. En la lámina 16-nov, P > 0 = el IC entrega a la red.
- **Errores a no cometer:**
  - conectar 0V_a, 0V_b y 0V_c al neutro;
  - confundir el PCC con el neutro;
  - suponer barra DC común, operación en isla o hardware definitivo;
  - mezclar el secundario (por MR) con el lazo rápido (por fase);
  - volver a la ley de SOC con τ.
- **No inventar:** si algo depende de un archivo que no está aquí, pedirlo.

## 5. Pendientes abiertos
1. **Simulación PLECS** (`documentos/simulacion/MicroRed_DC_Validacion.plecs`): abrirla en PLECS, corregir errores y comparar con `referencia_microred_dc.py`. Valores esperados: escenario 1 con V_dc entre 394 y 405 V y restauración en ~0,2 s; escenario 2 con SOC 0,50 → 0,85 → 0,42. El modelo **nunca se ha ejecutado en PLECS**. La referencia Python necesita `PPV.csv`, que **no está en la carpeta** (pedírselo a Felipe).
2. **Siguiente paso aprobado por Espina:** conectar la Micro-red validada a la red (IC grid-following) y observar su comportamiento.
3. **Terciario:** definir indicadores y entradas (Espina sugirió un balance entre la generación FV/BESS/EV y la demanda por fase de la S/E), la envolvente por MR, el margen m, τ de la reserva y ε̄_k. Revisar literatura (`documentos/pautas/lecturas-terciario-10nov.md`).
4. **Qué pasa cuando una MR se equivoca en su pronóstico:** el error consume reserva de energía; hay que formalizarlo.
5. **Tiempo real:** plataforma por definir (PLECS RT Box es la opción natural); compresión de tiempo κ para el terciario.
6. **Revisión sistemática de literatura** para confirmar la brecha candidata.

## 6. Fuera de alcance
No mezclar con otros proyectos de Felipe (Electra Consultora, proyectos SEC, paper EVSE, laboratorio de Sistemas Lineales, plan de doctorado) salvo que él lo pida.
