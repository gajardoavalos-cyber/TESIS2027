# Simulación PLECS micro-red DC

- **Enlace:** https://claude.ai/chat/7e6e1711-b7d6-47c5-9847-9ccd945719e1
- **Última actualización:** 12-nov-2026 · 29 turnos

## Pedido de Felipe (textual)
> "Se adjunta la información que dice relación con una simulación en PLECS de recursos renovables. Te las adjunto porque me interesa que se pueda sacar en limpio el modelo del PPV y el de la batería; recuerda que ahora estoy en la etapa de realizar la simulación de mi micro-red DC con control primario y secundario, sumado a que tenga incorporado los modelos de PPV, batería y cargador de vehículos EV. Quiero que tomes todo esto en consideración para que me des un archivo PLECS que tenga todo esto dispuesto para simular y validar la primera parte de la simulación de la tesis. Me interesa mucho eso, ya que es algo que le debo saber mostrar al profesor para la próxima reunión el día lunes 16. Por otro lado, también se adjunta el modelo de un convertidor DC para que lo uses como base para la simulación. Me interesa que además de realizar el archivo para que lo pueda modelar, también puedas darme un paso a paso de manera muy pedagógica para que esté al tanto y pueda explicar lo que se va a disponer en la simulación. Guíate en la memoria del chat de este proyecto denominado 'Validación del planteamiento de micro-redes' para entender más contextualmente lo que requiero."

## Archivos que adjuntó Felipe (no están en el Proyecto; pedirlos si se necesitan)
- `Modelos_ERNC.plecs`: modelos FV y batería de un laboratorio de ERNC.
- Modelo de un convertidor DC, usado como base.
- `PPV.csv`: perfiles horarios de irradiancia y temperatura (enero/julio). **Lo necesita `referencia_microred_dc.py`** y no está en esta carpeta.

## Resultado
- **`documentos/simulacion/MicroRed_DC_Validacion.plecs`:** modelo promedio de una Micro-red DC (bus de 400 V).
  - **Ramas:** FV (RS6F-200M, 2 strings × 8 módulos), BESS (6,5 Ah × 9 en paralelo, 360 V, ±5 kW), cargador EV (3,7 kW), carga DC e IC (fuente de potencia), sobre un bus con C = 4,7 mF.
  - **Control primario:** lazos de corriente PI discretos (Ts = 1/15000 s) y droop V–I en la BESS (y opcionalmente en el EV).
  - **Control secundario:** PI que restaura V_dc, más reglas de SOC: recorte FV, reducción del EV y límites de la BESS.
  - **Escenario 1 (validación dinámica, 3,4 s):** V_dc entre 394 y 405 V; el secundario restaura en unos 0,2 s.
  - **Escenario 2 (día comprimido, 1 s = 1 h):** el SOC sube de 0,50 a 0,85 y termina el día en 0,42.
  - **Organización de la planta** (última versión): un subsistema por equipo (PV, BESS, EV, carga DC), con el control afuera, igual que en la lámina de niveles. Etiquetas Goto/From con prefijos `pv_`, `bt_`, `ev_`, `ld_`.
  - **Revisión:** Claude no tiene PLECS, así que **el archivo no se ha probado en PLECS**. Pasó un verificador propio: conexiones completas, bornes bien numerados, Goto/From únicos y con su par, tramos solo horizontales o verticales, y quiebres a ≥ 45 px de cada bloque para evitar el error "connection segment".
- **`documentos/simulacion/referencia_microred_dc.py`:** las mismas ecuaciones en Python, para obtener las formas de onda esperadas y compararlas con PLECS. Si PLECS da algo distinto, hay que revisar el modelo PLECS.
- **Guía pedagógica paso a paso.** Quedó en la conversación y no está en el Proyecto: mapa del archivo, cómo leer cada paso y la lista de prefijos de etiquetas.
- **Orden sugerido para mostrarlo el lunes 16:** primero la lámina de niveles, luego el nivel superior del archivo y después el bloque de la Micro-red con los cuatro equipos en el bus.
